/*
    client.cpp
    BIF 3C1
    Alexander Grafl
    Philipp Müller
*/
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <string.h>
#include <iostream>
#include <termios.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iterator>

#define BUF 1024

using namespace std;

string hideInput();
bool sendAttachment(int socket, string filePath);
bool recieveAttachment(int socket, string fileUrl);
vector<string> getFilePath(string path);
vector<string> split(const string &s, char delim);

int main (int argc, char **argv)
{
    int create_socket, portNb, check, size, i;
    char buffer[BUF];
    struct sockaddr_in address;
    string lastCommand, password;

    if( argc < 2 )
    {
        printf("Wrong number of Arguments!\nUsage: %s ServerAddress Port\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    portNb = atoi(argv[2]);

    if ((create_socket = socket (AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Socket error");
        return EXIT_FAILURE;
    }

    memset(&address,0,sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons (portNb);
    inet_aton (argv[1], &address.sin_addr);

    if (connect ( create_socket, (struct sockaddr *) &address, sizeof (address)) == 0)
    {
        printf ("Connection with server (%s) established\n", inet_ntoa (address.sin_addr));
        size=recv(create_socket,buffer,BUF-1, 0);
        if (size>0)
        {
            buffer[size]= '\0';
            printf("%s",buffer);
            if(strncmp(buffer,"ERR",3) == 0)
            {
            	close (create_socket);
                return EXIT_FAILURE;
            }
        }
    }
    else
    {
        perror("Connect error - no server available");
        return EXIT_FAILURE;
    }

    do
    {
        /*command*/
        size=recv(create_socket,buffer,BUF-1, 0);
        if (size < 0)
        {
            perror("recv error");
            return EXIT_FAILURE;

        }
        buffer[size]= '\0';
        printf("%s",buffer);
        if( strncmp(buffer,"ERR",3) == 0) return EXIT_FAILURE;
        if( strncmp(buffer,"Password: ",10) == 0)
        {
        	password = hideInput();
        	strcpy(buffer,password.c_str());
        	send(create_socket, buffer, strlen(buffer), 0);
        }
        else
        {
        	fgets (buffer, BUF, stdin);
        	lastCommand = string(buffer);
    		send(create_socket, buffer, strlen(buffer)-1, 0);
        }

        /*** SEND ***/
        if(lastCommand == "send\n")
        {
            check = 0;
            /* Sender, Receiver, Subject */
            for(i = 0; i < 2; i++)
            {
                size=recv(create_socket,buffer,BUF-1, 0);
                if(size < 0)
                {
                    perror("recv error");
                    return EXIT_FAILURE;
                }
                buffer[size]= '\0';
                printf("%s",buffer);
                if(strncmp(buffer,"ERR",3) == 0)
                {
                    check = -1;
                    break;
                }
                fgets (buffer, BUF, stdin);
                send(create_socket, buffer, strlen (buffer)-1, 0);
            }
            /* Content */
            if (check == 0)
            {
            	size=recv(create_socket,buffer,BUF-1, 0);
                if(size < 0)
                {
                    perror("recv error");
                    return EXIT_FAILURE;
                }
                buffer[size]= '\0';
                printf("%s",buffer);

                do
                {
                    fgets (buffer, BUF, stdin);
                    send(create_socket, buffer, strlen (buffer), 0);
                }
                while(strcmp(buffer,".\n") != 0);
                /* ** ATTACHMENT **/
                size=recv(create_socket,buffer,BUF-1, 0);
                if(size < 0)
                {
                    perror("recv error");
                    return EXIT_FAILURE;
                }
                buffer[size]= '\0';
                printf("%s",buffer);
                fgets (buffer, BUF, stdin);
                int len = strlen(buffer);
                if(buffer[len-1] == '\n') buffer[len-1] = 0;
                send(create_socket, buffer, strlen (buffer), 0);
                if(buffer[0] != 0)
                {
                    if(!sendAttachment(create_socket, string(buffer)))
                    {
                        printf("ERROR SENDING FILE!\n");
                    }
                }
                else
                {
                     printf("No attachment!\n");
                }
            }

        }

        /*** LIST ***/
        /*
        	ToDo:
        		-sometimes gets stucked
        		-empty list => gets stucked
        		- fuck it.
        */
        if(lastCommand == "list\n")
        {
            do
            {
                memset(&buffer[0], '\0', sizeof(buffer));
                size=recv(create_socket,buffer,BUF-1, 0);
        	 	if(size <= 0)
                {
                    perror("recv error");
                    return EXIT_FAILURE;
                }
                buffer[size] = '\0';
               	if(strncmp(buffer, "FIN",3) == 0) break;
                printf("%s",buffer);
            }
            while(strncmp(buffer, "ERR",3) != 0);
        }


        /*** DEL & READ ***/
        if(lastCommand == "del\n" || lastCommand == "read\n")
        {
            //ID
            size=recv(create_socket,buffer,BUF-1, 0);
            if(size < 0)
            {
                perror("recv error");
                return EXIT_FAILURE;
            }
            buffer[size]= '\0';
            printf("%s",buffer);
            if (strncmp(buffer,"ERR",3) == 0) continue;
            fgets (buffer, BUF, stdin);
            send(create_socket, buffer, strlen (buffer), 0);

            string attachmentLine;
            do
            {   attachmentLine = string(buffer);
                size=recv(create_socket,buffer,BUF-1, 0);
                if(size <= 0)
                {
                    perror("recv error");
                    return EXIT_FAILURE;
                }
                buffer[size]= '\0';
                printf("%s",buffer);
                if(strncmp(buffer,"ERR",3) == 0) break;
            }
            while(string(buffer) != "OK\n");
            //Download attachment
            if(lastCommand == "read\n")
            {
                if(attachmentLine != "No file attached.\n")
                {
                    size=recv(create_socket,buffer,BUF-1, 0);
                    if(size < 0)
                    {
                        perror("recv error");
                        return EXIT_FAILURE;
                    }
                    buffer[size]= '\0';
                    printf("%s",buffer);
                    if (strncmp(buffer,"ERR",3) == 0) continue;
                    fgets (buffer, BUF, stdin);
                    send(create_socket, buffer, strlen (buffer), 0);
                    if(buffer[0] == 'y')
                    {
                        string fileName = split(split(attachmentLine, '\n').back(), ' ').front();
                        if(recieveAttachment(create_socket, fileName))
                        {
                            printf("File \"%s\" downloaded.", fileName.c_str());
                        }
                        else
                        {
                            perror("Error downloading file!");
                            return EXIT_FAILURE;
                        }
                    }
                }
            }
        }
    }
    while (lastCommand != "quit\n");
    close (create_socket);
    return EXIT_SUCCESS;
}

string hideInput()
{
	termios oldt;
    tcgetattr(STDIN_FILENO, &oldt);
    termios newt = oldt;
    newt.c_lflag &= ~ECHO;
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    string s;
    getline(cin, s);

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);

    return s;
}

bool sendAttachment(int socket, string rawFilePath)
{
    ifstream infile;
    int count = 0;
    long bytesSent = 0;
    char buf[BUF];
    string fileName;
    string path = ".";
    vector<string> filePath = getFilePath(rawFilePath);
    fileName = filePath.back();
    filePath.pop_back();
    if(filePath.size() > 0)
    {
        for(vector<string>::iterator i = filePath.begin(); i != filePath.end(); ++i)
        {
            path = path + "/" + (*i);
            count ++;
        }
        path += "/";
    }
    chdir(path.c_str());
    infile.open(fileName.c_str(), ios::in | ios::binary);
    if (infile.fail() == 1)
    {
        infile.close();
        cout << "file open fail" << endl;
        while(count--) chdir("..");
        return false;
    }

    /* File Size */
    infile.seekg(0, ifstream::end);
    long fileSize = infile.tellg();
    sprintf(buf, "%ld", fileSize);
    send(socket, buf, sizeof(buf), 0);
    /* set cursor to the beginning of the file */
    infile.seekg(0, ios::beg);
    char sendBuffer[BUF];
    while(bytesSent < fileSize)
    {
        if((fileSize - bytesSent) > BUF)
        {
            infile.read (sendBuffer, sizeof(sendBuffer));
            bytesSent += send(socket, sendBuffer, sizeof(sendBuffer), 0);
        }
        else
        {
            infile.read (sendBuffer, (fileSize - bytesSent));
            bytesSent += send(socket, sendBuffer, (fileSize - bytesSent), 0);
        }

    }

    infile.close();
    while(count--) chdir("..");
    return true;
}

bool recieveAttachment(int socket, string fileUrl)
{
    int size;
    long fileSize;
    char buffer[BUF];
    size = recv(socket, buffer, BUF, 0);
    if(size <= 0)
    {
        return false;
    }

    fileSize = atol(buffer);
    ofstream file;
    long bytesRecieved = 0;
    char dataBuffer[BUF];
    file.open(fileUrl.c_str(), ios::out | ios::binary | ios::trunc);
    if(file.is_open())
    {
        while(bytesRecieved < fileSize)
        {
            if((fileSize - bytesRecieved) > BUF)
            {
                size = recv(socket, dataBuffer, sizeof(dataBuffer), 0);
                bytesRecieved += size;
                if(size > 0)
                {
                   file.write(dataBuffer, size);
                }
                else return false;
            }
            else
            {
                size = recv(socket, dataBuffer, (fileSize - bytesRecieved), 0);
                bytesRecieved += size;
                if(size > 0)
                {
                   file.write(dataBuffer, size);
                }
                else return false;
            }

        }

    }
    file.close();
    return true;
}

vector<string> &split(const string &s, char delim, vector<string> &elems) {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}


vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}

vector<string> getFilePath(string path)
{
    vector<string> splitFileName;
    replace(path.begin(), path.end(), '\\', '/');
    splitFileName = split(path, '/');
    return splitFileName;
}

